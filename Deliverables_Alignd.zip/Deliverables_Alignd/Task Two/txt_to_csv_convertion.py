#Katlego_Malesa\Analytics_Engineering_Assessment
#filename:txt_to_csv_convertion.py
#Now am importing the modules that am going to use
import sys,re,pandas


print ("###############################################################")
print ("Alignd Analytics Engineering Assessment 2025")
print ("Converting .txt file to .csv file script")
print ("###############################################################")

#Now  Am Reading the Health_lapses Parquet file
#dataframe1 = pandas.read_parquet("health_lapses.parquet", engine="fastparquet")

#Now am Converting the Health_lapses Parquet file to CSV file
#dataframe1.to_csv('health_lapses.csv', index=False)


# Now am Reading the health_products text file into a DataFrame
dataframe = pandas.read_csv("health_products.txt")


# Now am writting the DataFrame to health_products CSV file
dataframe.to_csv("health_products.csv", index=False)





 
 
 
 
 
 




