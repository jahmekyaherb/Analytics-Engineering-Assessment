--Patients Table:Raw data of patients
create table insure_dev.raw_patients(
patient_id integer not null primary key 
,name varchar(15) not null
,date_of_birth date not null
,gender varchar(3) not null

);



--Patients Table:Raw data of patients
--drop table insure_dev.raw_claims
create table insure_dev.raw_claims(
claim_id varchar(36) not null primary key 
,patient_id integer not null
,claim_date date not null
,claim_amount numeric(19,2) null
,diagnosis_code varchar(3) not null


);

--stg claim table
create table insure_dev.stg_claims(
claim_id varchar(36) not null primary key 
,patient_id integer not null
,claim_date date not null
,claim_amount numeric(19,2) null
,diagnosis_code varchar(3) not null
,claim_month date not null

);

--Patients Table:Raw data of patients
create table insure_dev.dim_patients(
First_claim_date date null
,Total_number_of_claims integer
,Total_claim_amount numeric(19,2)
,Days_since_first_claim integer
);

--query for dim_patients
select first_claim_date
,Total_number_of_claims
,Total_claim_amount 
,Days_since_first_claim

from(
select max(claim_date) as first_claim_date
       ,count(claim_id) as Total_number_of_claims
 ,sum(claim_amount) as Total_claim_amount 
,(claim_date-claim_month) as Days_since_first_claim
from insure_dev.stg_claims

group by claim_date,claim_month
) a
---join raw patients  with stg claims

SELECT 
a.patient_id
,a.name 
,a.date_of_birth 
,a.gender 
,b.claim_id 
--,b.patient_id
,b.claim_date
,b.claim_amount
,b.diagnosis_code
,b.claim_month 


FROM insure_dev.raw_patients a

Join insure_dev.stg_claims b 
on a.patient_id=b.patient_id 


with patients as (
    select * from insure_dev.dim_patients
),

-- Add your logic here to join with stg_claims
---join raw patients  with stg claims

SELECT 
a.patient_id
,a.name 
,a.date_of_birth 
,a.gender 
,b.claim_id 
--,b.patient_id
,b.claim_date
,b.claim_amount
,b.diagnosis_code
,b.claim_month 


FROM insure_dev.raw_patients a

Join insure_dev.stg_claims b 
on a.patient_id=b.patient_id

final as (
    select * from patients
)

select * from final


---------------------------------------------------------------


-- Working example: staging model for raw patient claims
-- Cleans data and derives claim_month

with source as (
    select * from insure_dev.raw_claims
),
renamed as (
    select
        claim_id,
        patient_id,
        cast(claim_date as date) as claim_date,
        cast(claim_amount as numeric) as claim_amount,
        diagnosis_code,
        date_trunc('month', cast(claim_date as date)) as claim_month
    from source
)
select * from renamed
