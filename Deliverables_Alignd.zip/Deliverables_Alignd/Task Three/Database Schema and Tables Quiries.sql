-- DROP SCHEMA insure_dev;
--Insurance Schema:
CREATE SCHEMA insure_dev AUTHORIZATION postgres;


--Clients Table : This dataset represents all of the insurer�s clients at 1 January 2023.
--drop table  insure_dev.Clients
Create table insure_dev.Clients(
id	varchar(6) not null primary key 
,gender	varchar(6)
,age int not null
,province varchar(3)	
,income	numeric(19,2)  null
,bank	varchar(10)
,num_products int not null	
,client_duration int not null	
,payment varchar(15) null	
,distrn varchar(10) not null
);


--Health Products: This data sets out premiums for the health insurance policy for the 2023 calendar year.
--drop table insure_dev.Health_Products
Create table insure_dev.Health_Products(
option	varchar(15) not null 
,single_premium	numeric(19,2) not null
,couple_premium numeric(19,2) not null
,family_premium numeric(19,2) not null	

);



--Health Lapses: This dataset reflects all health insurance policies in force on 1 January 2023, indicating whether or not they lapsed in 2023. There were no exits other than lapses in 2023.

Create table insure_dev.Health_Lapses(
id	varchar(6) not null primary key 
,option	varchar(15) not null 
,family	varchar(11) not null
,lapse_indicator int not null

);