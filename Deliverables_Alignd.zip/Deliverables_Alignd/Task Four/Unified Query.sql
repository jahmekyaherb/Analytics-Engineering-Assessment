--1.Unified query
SELECT a.id
, a.gender
, a.age
, a.province
, a.income
, a.bank
, a.num_products
, a.client_duration
, a.payment
, a.distrn
, b.option
, b.family
, b.lapse_indicator
, c.single_premium 
, c.couple_premium 
, c.family_premium


FROM insure_dev.clients a

inner Join insure_dev.Health_Lapses b 
on a.id=b.id
full Join insure_dev.Health_Products c
on replace(c.option,'"','')=b.option;

--2.Duplicates records
SELECT d.id, COUNT(*)
FROM (SELECT a.id
, a.gender
, a.age
, a.province
, a.income
, a.bank
, a.num_products
, a.client_duration
, a.payment
, a.distrn
, b.option
, b.family
, b.lapse_indicator
, c.single_premium 
, c.couple_premium 
, c.family_premium


FROM insure_dev.clients a

inner Join insure_dev.Health_Lapses b 
on a.id=b.id
full Join insure_dev.Health_Products c
on replace(c.option,'"','')=b.option) d
GROUP BY d.id
HAVING COUNT(*) > 1;  

--2.What is the mean income per province and gender?
select avg(d.income) as average_income
,d.province as province
,d.gender as gender
from (SELECT a.id
, a.gender
, a.age
, a.province
, a.income
, a.bank
, a.num_products
, a.client_duration
, a.payment
, a.distrn
, b.option
, b.family
, b.lapse_indicator
, c.single_premium 
, c.couple_premium 
, c.family_premium


FROM insure_dev.clients a

inner Join insure_dev.Health_Lapses b 
on a.id=b.id
full Join insure_dev.Health_Products c
on replace(c.option,'"','')=b.option) d
group by d.province ,d.gender

--3.Which payment method is used by most customers per bank

select count(d.id) as Customer
,d.bank
,d.payment

from (SELECT a.id
, a.gender
, a.age
, a.province
, a.income
, a.bank
, a.num_products
, a.client_duration
, a.payment
, a.distrn
, b.option
, b.family
, b.lapse_indicator
, c.single_premium 
, c.couple_premium 
, c.family_premium


FROM insure_dev.clients a

inner Join insure_dev.Health_Lapses b 
on a.id=b.id
full Join insure_dev.Health_Products c
on replace(c.option,'"','')=b.option) d

group by d.payment,d.bank


 
